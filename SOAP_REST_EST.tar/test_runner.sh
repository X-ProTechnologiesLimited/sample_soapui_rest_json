#!/bin/bash
ic_root=/home/soapuser/ICE_CUBE_HOME
user_root=/home/soapuser
echo
echo -e "SOAP TEST RUNNER STARTING NOW............\n"
####### Clearing old logs for test run #######
echo -e "Clearing old logs for test run..............\n"
rm soapui-errors.log soapui.log test_output.log

#################################################################################
############## CLEARING UPM HH ################################################

echo "We are now refreshing the HH that would be used in the test ......... "

grep -v '#' IC_Properties.csv | awk -F ' ' '{print $4}' | sort -k1 | uniq > temp_HH

while read hhid
do
curl -s -o /dev/null -H "Content-Type: application/json" -H "Source-Type: CPE" -H "Source-ID: CPE" -X DELETE http://172.26.178.137:6040/upm/households/$hhid
echo "Deleting HHID: $hhid"
sleep 0.5
done < temp_HH
rm temp_HH


########## CREATING THE UNIQUE PARTY ID FOR THE PROMOCODE TRANSACTIONS FOR EACH TEST RUN ######

NEW_UUID=$(cat /dev/urandom | tr -dc 'a-zA-Z0-9' | fold -w 16 | head -n 1)
sed -i 's|UPARTYSTRING|'$NEW_UUID'|g' IC_Properties.csv

########### Reading the Test Config ###############################################
echo -e "Reading the Test Config......\n"
CMDC=`grep "CMDCVersionNumber" testrun_config.properties | awk -F '=' '{print $2}'`
HEP=`grep "HEPVersionNumber" testrun_config.properties | awk -F '=' '{print $2}'`
PROJ=`grep "Project" testrun_config.properties | awk -F '=' '{print $2}'`
IT=`grep "Iteration" testrun_config.properties | awk -F '=' '{print $2}'`
RUN=`grep "Run" testrun_config.properties | awk -F '=' '{print $2}'`
build_proj=`echo "$CMDC"_"$HEP"_"$PROJ"_"$IT"_"$RUN"`
PE=`grep "PriceEngine" testrun_config.properties | awk -F '=' '{print $2}'`

############### Copying Sample Project and ANT FILES #############################
echo -e "Copying Sample Project and ANT FILE...........\n"
cp soap_controller.xml build.xml
cp CMDC-HEP-ICE-CUBE-soapui-project_"$PE".xml CMDC-HEP-ICE-CUBE-soapui-project.xml
cp CMDC-HEP-ICE-CUBE-soapui-project.xml CMDC-HEP-ICE-CUBE-soapui-project_ant.xml


############# Creating reporting directories ###################################
echo -e "Creating Reporting Directories ..........\n"
if [[ ! -e "$ic_root/results/$build_proj" ]]; then
    mkdir $ic_root/results/$build_proj
elif [[ -d "$ic_root/results/$build_proj" ]]; then
    echo "$build_proj already exists" 1>&2
fi

############## Initialize ANT file ########################
echo -e "Ininializing ANT Files......\n"
sed -i 's|soap_project|'$build_proj'|g' build.xml
sed -i 's|'$ic_root'/results/latest_dir|'$ic_root/results/$build_proj'|g' build.xml
sed -i 's|CMDC_HEP_ICE_CUBE|'$build_proj'|g' CMDC-HEP-ICE-CUBE-soapui-project_ant.xml

############### Building Automated Test now ####################
echo -e "Building Automated Test Pack...........\n"
echo -e "Running Automated Test Pack..........\n"
sh $user_root/apache_ant/apache-ant-1.10.1/bin/ant

############### Copying Reports to HTML root ############

cp -R $ic_root/results/$build_proj /var/www/html/Test_Results/Functional/
cp $ic_root/global-groovy.log /var/www/html/Test_Results/Functional/$build_proj/test_output.log

######## REMOVING RUN FILES#########
rm -rf CMDC-HEP-ICE-CUBE-soapui-project_ant.xml
rm -rf build.xml
mv global-groovy.log test_output.log
sed -i 's|'$NEW_UUID'|UPARTYSTRING|g' IC_Properties.csv


echo -e '\n'
echo -e '\n'
echo -e "Test Complete!! Test Report Summary available at http://10.191.96.22/Test_Results/Functional/$build_proj/summary\n"
echo

###### EMAILING THE REPORT #########
echo -e "Mailing the test report to the specific audiences.....\n"
rm /tmp/email
now=$(date +%d%m%Y_%H_%M_%S)
curr_date_time=`echo $now`
echo "Test completed for following CMDC and HEP versions on $curr_date_time" >> /tmp/email
echo "CMDC version $CMDC" >> /tmp/email
echo "HEP version $HEP" >> /tmp/email
echo >> /tmp/email
echo "Test Report Summary available at http://10.191.96.22/Test_Results/Functional/$build_proj/summary" >> /tmp/email
echo "Test Output Log available at http://10.191.96.22/Test_Results/Functional/$build_proj/test_output.log" >> /tmp/email
mail -s "SOAP Results for ICE_CUBE functional test at $curr_date_time" -a test_output.log krishnendu.banerjee@sky.uk,swathi.ettapu@sky.uk < /tmp/email



